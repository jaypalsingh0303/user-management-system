<?php $__env->startSection('title'); ?>
    Profile
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <style>
        .profile-container {
            width: 360px;
            height: 360px;
            overflow: hidden;
            margin-bottom: 20px;
            border: 1px solid #eee;
            border-radius: 5px;
            position: relative;
        }

        .profile-container img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .profile-container .upload-icon {
            width: 35px;
            height: 35px;
            border-radius: 50%;
            background: gray;
            position: absolute;
            top: 10px;
            right: 10px;
            color: #ffff;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .profile-container .delete-icon {
            width: 35px;
            height: 35px;
            border-radius: 50%;
            background: red;
            position: absolute;
            top: 10px;
            right: 50px;
            color: #ffff;
            display: flex;
            justify-content: center;
            align-items: center;
            text-decoration: none;
        }
    </style>

    <div class="container">

        <div class="row">
            <div class="col-md-8 offset-md-2">
                <div class="card">
                    <div class="card-body">

                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger mb-4">
                                <ul class="mb-0 pb-0">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <?php if(session()->has("success")): ?>
                            <div class="alert alert-success mb-4">
                                <ul class="mb-0 pb-0">
                                    <li><?php echo e(session()->get("success")); ?></li>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <?php if(session()->has("error")): ?>
                            <div class="alert alert-danger mb-4">
                                <ul class="mb-0 pb-0">
                                    <li><?php echo e(session()->get("error")); ?></li>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <form action="<?php echo e(route("dashboard.profile.update")); ?>" method="post"
                              enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field("PUT"); ?>
                            <div class="row">
                                <div class="col-md-12">
                                    <h3 class="mb-4">Profile</h3>
                                </div>

                                <div class="col-md-12">
                                    <div class="d-flex justify-content-end">
                                        <div class="profile-container">
                                            <?php if($user->profile): ?>
                                                <img
                                                    src="<?php echo e(asset("storage/$user->profile")); ?>"
                                                    alt="profile">
                                            <?php else: ?>
                                                <img
                                                    src="<?php echo e(asset("uploads/profile/profile.png")); ?>"
                                                    alt="profile">
                                            <?php endif; ?>

                                            <?php if($user->profile): ?>
                                                <a href="<?php echo e(route("dashboard.profile.delete")); ?>" class="delete-icon">
                                                    <i class="fa fa-trash"></i>
                                                </a>
                                            <?php endif; ?>

                                            <label for="profile" class="upload-icon">
                                                <i class="fa fa-edit"></i>
                                                <input type="file" hidden name="profile" class="form-control"
                                                       id="profile"
                                                       accept=".jpeg, .jpg, .png">
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="first_name" class="form-label">First Name*</label>
                                        <input type="text" name="first_name" class="form-control" id="first_name"
                                               maxlength="50" value="<?php echo e($user->first_name); ?>"
                                               required>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="last_name" class="form-label">Last Name</label>
                                        <input type="text" name="last_name" class="form-control" id="last_name"
                                               value="<?php echo e($user->last_name); ?>"
                                               maxlength="50">
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="email" class="form-label">Email*</label>
                                        <input type="email" name="email" class="form-control" id="email" maxlength="50"
                                               value="<?php echo e($user->email); ?>"
                                               required>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="mobile_number" class="form-label">Mobile Number*</label>
                                        <input type="text" name="mobile_number" class="form-control" id="mobile_number"
                                               maxlength="10" value="<?php echo e($user->mobile_number); ?>"
                                               required>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="password" class="form-label">Password*</label>
                                        <input type="password" name="password" class="form-control" id="password"
                                               maxlength="20">
                                        <small>One uppercase letter, one lowercase letter and special character</small>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="password_confirmation" class="form-label">Confirm Password*</label>
                                        <input type="password" name="password_confirmation" class="form-control"
                                               id="password_confirmation" maxlength="20">
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="pan_card" class="form-label">Pan Card*</label>
                                        <input type="text" name="pan_card" class="form-control"
                                               id="pan_card" maxlength="10" value="<?php echo e($user->pan_card); ?>" required>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="date_of_birth" class="form-label">Date of Birth*</label>
                                        <input type="date" name="date_of_birth" class="form-control"
                                               id="date_of_birth" min="<?php echo e($min_date_formatted); ?>"
                                               max="<?php echo e($max_date_formatted); ?>" value="<?php echo e($user->date_of_birth); ?>" required>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="mb-3">
                                        <label for="gender" class="form-label">Gender*</label>
                                        <select name="gender" class="form-control" id="gender" required>
                                            <option value="" disabled selected>Select one</option>
                                            <option value="male" <?php echo e($user->gender == "male"?"selected":""); ?>>Male</option>
                                            <option value="female" <?php echo e($user->gender == "female"?"selected":""); ?>>Female
                                            </option>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="mb-3">
                                        <label for="address" class="form-label">Address</label>
                                        <textarea name="address" class="form-control" id="address"
                                                  maxlength="200"><?php echo e($user->address); ?></textarea>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="text-end">
                                        <button class="btn btn-primary">Save</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp-8.2\htdocs\jay\user-management-system\resources\views/dashboard/users/profile.blade.php ENDPATH**/ ?>