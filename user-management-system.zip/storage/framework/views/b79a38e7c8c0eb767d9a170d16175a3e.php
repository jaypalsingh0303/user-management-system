<footer>
    <div class="text-center">
        <p class="mb-0">User management system.</p>
    </div>
</footer>
<?php /**PATH D:\xampp-8.2\htdocs\jay\user-management-system\resources\views/layouts/footer.blade.php ENDPATH**/ ?>