<footer>
    <div class="text-center">
        <p class="mb-0">User management system.</p>
    </div>
</footer>
